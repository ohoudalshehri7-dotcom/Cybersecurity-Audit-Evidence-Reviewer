AUDIT EVIDENCE REVIEWER — FICTIONAL SAMPLE DATA
================================================

All names, IDs, roles, systems, dates, references, and records in this package are fictional.
Do not treat these files as real organizational evidence.

Files
-----
01_Control_Requirement_UAR.docx
02_Evidence_User_Access_Review_Report.docx
03_Evidence_Active_User_Listing.docx
04_Evidence_Manager_Approval_Record.docx

Scenario
--------
A fictional Finance Department performs a quarterly User Access Review for Q3 2026.
The evidence package contains:
- The control requirement.
- A review report with six account decisions and one removal action.
- A point-in-time account listing.
- A manager approval record.

How to use
----------
Upload the four DOCX files to Gemini (subject to the tool's current upload options).
Ask Gemini to compare the Control Requirement with the three Evidence documents.
Require it to distinguish supported items, missing/unclear evidence, and potential gaps.
Do not ask it to issue a final control effectiveness conclusion.

Important
---------
This is the initial clean sample dataset. Additional deliberately messy, edge-case, and
security-test variants should be created separately so the original baseline remains unchanged.
